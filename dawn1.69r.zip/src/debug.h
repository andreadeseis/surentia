/**************************************************************************/
// debug.h - set which debug logging you want turned on
/***************************************************************************
 * The Dawn of Time v1.69r (c)1997-2004 Michael Garratt                    *
 * >> A number of people have contributed to the Dawn codebase, with the   *
 *    majority of code written by Michael Garratt - www.dawnoftime.org     *
 * >> To use this source code, you must fully comply with the dawn license *
 *    in licenses.txt... In particular, you may not remove this copyright  *
 *    notice.                                                              *
 **************************************************************************/
#ifndef DEBUG_H
#define DEBUG_H

//#define DEBUG_TELNET_OPTION_NEGOTIATION 
//#define DEBUG_PACKET_LOGGING_IN_READ_FROM_BUFFER
//#define DEBUG_MCCP_SEND_TEXT_MESSAGE_AROUND_COMPRESSION_CHANGES

//#define SHOW_CLIENT_DETECTION	// if defined, the client detection process is displayed to client

//#define DEBUG_SHOW_HOTREBOOT_INFO	// if defined, debug info is displayed to imms during hotreboot
//#define DEBUG_HOTREBOOT_TO_LOG	// if defined, hotreboot logs to the log file more info

//#define MEM_DEBUG

//#define DEBUG_HOTREBOOT_TO_LOG

#endif // DEBUG_H

